#!/system/bin/sh
MODDIR=${0%/*}

/system/bin/oneinit &