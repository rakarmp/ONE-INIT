# ONE INIT 

one init is a magisk module designed for devices with Snapdragon SoC, with code based on Dragonboost and revamped to be more stable, flexible, and of course fast.

## License

This module is licensed under the [MIT License](https://opensource.org/license/mit).


#### Powered ONEINIT C Library